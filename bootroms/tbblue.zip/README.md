# ZX_Spectrum_Next_FPGA

https://gitlab.com/SpectrumNext/ZX_Spectrum_Next_FPGA

Official ZX Spectrum Next FPGA Cores Repository

Licensed under GNU GENERAL PUBLIC LICENSE Version 3

The binary files in this archive were extracted from:

https://gitlab.com/SpectrumNext/ZX_Spectrum_Next_FPGA/-/blob/fa55357d7eafb46b98cff3b2dd060f3f5a713edd/cores/zxnext/src/rom/bootrom.vhd

https://gitlab.com/SpectrumNext/ZX_Spectrum_Next_FPGA/-/blob/cfffa702a65d1d40fa2e0d06b241c782085c3a9a/cores/zxnext/src/rom/bootrom_ab.vhd
